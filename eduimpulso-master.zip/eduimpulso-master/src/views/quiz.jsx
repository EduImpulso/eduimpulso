import Quizz from '../components/quiz/quiz';

const Quiz = () => {
    return(
        <Quizz/>

    )
}

export default Quiz;
import Carreiras from '../components/Carreiras'

const Carreira = () =>{
    return(
        <Carreiras/>
    )
}

export default Carreira;
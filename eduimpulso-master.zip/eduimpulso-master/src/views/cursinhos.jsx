import Cursos from '../components/Cursos';

const Curso = () =>{
    return(
        <Cursos/>
    )
}

export default Curso;
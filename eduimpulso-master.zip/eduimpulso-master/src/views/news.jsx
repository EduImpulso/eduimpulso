import News from '../components/News';

const New = () => {
    return(
        <News/>

    )
}

export default New;

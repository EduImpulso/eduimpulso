import Descricao from '../components/Descricao'

const Descr = () =>{
    return(
        <Descricao/>
    )
}

export default Descr;
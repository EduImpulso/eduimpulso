import Inteligence from '../components/Inteligence';

const Inteligences = () => {
    return(
        <Inteligence/>
    )
}


export default Inteligences;

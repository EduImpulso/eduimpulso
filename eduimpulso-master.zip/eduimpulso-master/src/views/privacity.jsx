import PP from '../components/Privacity';

const Privacity = () => {
    return(
        <PP/>

    )
}

export default Privacity;
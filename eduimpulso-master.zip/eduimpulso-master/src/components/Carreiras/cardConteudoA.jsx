import React from 'react';

const CardConteudoA = (props) =>{
    return(
        <>
<div className="cardArea col-12 col-lg-3 my-3 mx-3 p-0">
    <div>
        <h5 className="titleColorCards text-center m-2">{props.h5}</h5>
    </div>

    <a href= {props.href} target="_blank" className=" d-flex justify-content-center"><img className="imgCardArea img-fluid" style={{padding:"20px", width:"70%"}} src={props.src} alt="" /></a>
</div>
            
            
            
                
      
        
</>
        )
        };
export default CardConteudoA;